<main class="page ql-editor flex-1 p-5">
    {!! $page->content !!}
</main>
